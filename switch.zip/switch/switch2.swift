let matchmakingRank = 143

func determinePlayerLeague(from rank: Int)
{
    switch rank {
        case 0:
        print("Play the game to determine the league")
        case 1..<50:
        print("You are in BRONZE league")
        case 50..<100:
        print("You are in SILVER league")
        case 100..<200:
        print("You are in GOLD league")
        default:
        print("You are in a league of your own. We don't know where you are.")
    }
}

determinePlayerLeague(from: matchmakingRank)