enum Phone {
    case iPhone11Pro      
    case iPhoneSE       
    case pixel            
    case nokia           
}

func getSeansOpinion(on phone: Phone)
{
    switch phone {
        case .iPhone11Pro:
        print("This will be my next phone")
        case .iPhoneSE:
        print("I dislike this phone size")
        case .pixel:
        print("Hardware is great")
        case .nokia:
        print("Can't be broken")
    }
}

getSeansOpinion(on : .nokia)