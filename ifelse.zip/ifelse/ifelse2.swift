var myHighScore = 98
var yourHighScore = 95

if myHighScore > yourHighScore
{
    print("I win")
}
else
{
    print("You win")
}