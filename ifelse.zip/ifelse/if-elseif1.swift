var highScore = 278

if highScore > 500 {
    print("You are the best")
}
else if highScore > 250 {
    print("You are average")
}
else if highScore > 100 {
    print("You need improvement")
}
else{
    print("You are too bad")
}