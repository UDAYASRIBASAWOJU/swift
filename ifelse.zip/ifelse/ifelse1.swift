var isDarkModeOn = false

if isDarkModeOn 
{
    print("That's how it should be.")
}
else
{
    print("It shouldn't be like this.")
}