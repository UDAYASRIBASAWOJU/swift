for i in 0..<25 {
    print(i)
}