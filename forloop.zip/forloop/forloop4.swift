var randomInts: [Int] = []

for i in 0..<25 {
    let randomNumber = Int.random(in: 0...100) 
    randomInts.append(randomNumber)
}

print(randomInts)