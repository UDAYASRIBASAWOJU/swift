let allStars = ["David", "Davis", "Harden", "Doncic", "Leonard"]

for player in allStars where player == "Harden" {
    print(player)
}