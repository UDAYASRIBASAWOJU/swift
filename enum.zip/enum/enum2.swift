enum Phone : String {
    case iPhone11Pro   ==   "This will be my next phone"
    case iPhoneSE      ==   "I dislike this phone size"
    case pixel         ==   "Hardware is great"
    case nokia         ==   "Can't be broken"
}

func getSeansOpinion(on phone: Phone)
{
    print(phone.rawValue)
}

getSeansOpinion(on : .pixel)