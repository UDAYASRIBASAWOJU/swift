enum Phone {
    case iPhone11Pro
    case iPhoneSE
    case pixel
    case nokia
}

func getSeansOpinion(on phone: Phone)
{
    if phone == .iPhone11Pro {
        print("This will be my next phone")
    } else if phone == .iPhoneSE {
        print("I dislike this phone size")
    } else if phone == .pixel {
        print("Hardware is great")
    } else {
        print("Can't be broken")
    }
}

getSeansOpinion(on : .iPhoneSE)